from rest_framework import serializers
from .models import branches

class branchesSerializer(serializers.ModelSerializer):
    class Meta:
        model=branches
        fields='__all__'
