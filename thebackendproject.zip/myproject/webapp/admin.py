from django.contrib import admin
from .models import branches

admin.site.register(branches)
# Register your models here.
