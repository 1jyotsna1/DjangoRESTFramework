from django import forms
from webapp.models import branches

class branchesForm(forms.ModelForm):
    class Meta:
        model=branches
        fields="__all__"
