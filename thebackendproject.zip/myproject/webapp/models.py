from django.db import models
# Create your models here.
class branches(models.Model):
    ifsc=models.CharField(max_length=11)
    branch=models.CharField(max_length=11)
    address=models.CharField(max_length=110)
    city=models.CharField(max_length=15)
    district=models.CharField(max_length=11)
    state=models.CharField(max_length=11)
    bank_id=models.IntegerField()

    def __str__(self):
        return self.branch

    class Meta:
        db_table="employees"
